create view V_$JAVA_SERVICES as
  select "NAME","CON_ID" from v$java_services
/

