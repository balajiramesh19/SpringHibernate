create view CDB_BLOCKERS as
  SELECT k."HOLDING_SESSION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_BLOCKERS") k
/

comment on table CDB_BLOCKERS
is ' in all containers'
/

