create view V_$IM_ADOTASKS as
  select "TASK_ID","CREATION_TIME","STATUS","IM_SIZE","CON_ID" from v$im_adotasks
/

