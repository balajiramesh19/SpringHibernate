create view GV_$FS_OBSERVER_HISTOGRAM as
  select "INST_ID","OBSERVER_NAME","OBSERVER_HOST","WAIT_TIME","WAIT_COUNT","LAST_UPDATE_TIME","CON_ID" from gv$fs_observer_histogram
/

