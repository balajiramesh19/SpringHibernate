create view V_$SQL_REOPTIMIZATION_HINTS as
  select "ADDRESS","HASH_VALUE","SQL_ID","CHILD_NUMBER","HINT_ID","HINT_TEXT","CLIENT_ID","REPARSE","CON_ID" from v$sql_reoptimization_hints
/

