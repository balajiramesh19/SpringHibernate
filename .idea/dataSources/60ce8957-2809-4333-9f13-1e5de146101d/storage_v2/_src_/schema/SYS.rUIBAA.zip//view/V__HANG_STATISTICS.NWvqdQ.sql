create view V_$HANG_STATISTICS as
  select "STATISTIC#","NAME","VALUE","CON_ID" from v$hang_statistics
/

