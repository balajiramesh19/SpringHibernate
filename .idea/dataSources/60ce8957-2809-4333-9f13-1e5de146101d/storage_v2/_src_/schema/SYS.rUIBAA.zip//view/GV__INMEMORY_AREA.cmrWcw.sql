create view GV_$INMEMORY_AREA as
  select "INST_ID","POOL","ALLOC_BYTES","USED_BYTES","POPULATE_STATUS","CON_ID" from gv$inmemory_area
/

