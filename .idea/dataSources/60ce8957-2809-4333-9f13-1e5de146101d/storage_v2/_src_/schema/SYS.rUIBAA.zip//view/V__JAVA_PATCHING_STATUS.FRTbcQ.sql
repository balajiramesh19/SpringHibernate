create view V_$JAVA_PATCHING_STATUS as
  select "OPERATION","STATUS","CON_ID" from v$java_patching_status
/

