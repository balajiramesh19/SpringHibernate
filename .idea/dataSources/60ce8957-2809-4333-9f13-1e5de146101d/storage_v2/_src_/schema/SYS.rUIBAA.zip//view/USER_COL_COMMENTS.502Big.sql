create view USER_COL_COMMENTS as
  select TABLE_NAME, COLUMN_NAME, COMMENTS, ORIGIN_CON_ID
from NO_ROOT_SW_FOR_LOCAL(INT$DBA_COL_COMMENTS)
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
/

comment on table USER_COL_COMMENTS
is 'Comments on columns of user''s tables and views'
/

