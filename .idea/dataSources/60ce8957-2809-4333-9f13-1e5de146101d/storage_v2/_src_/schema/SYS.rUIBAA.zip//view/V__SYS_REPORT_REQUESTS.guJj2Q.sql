create view V_$SYS_REPORT_REQUESTS as
  select "CON_ID","REPORT_CLASS","REPORT_REF","REF_LEN","PRIORITY","GENERATION_TIME" from v$sys_report_requests
/

