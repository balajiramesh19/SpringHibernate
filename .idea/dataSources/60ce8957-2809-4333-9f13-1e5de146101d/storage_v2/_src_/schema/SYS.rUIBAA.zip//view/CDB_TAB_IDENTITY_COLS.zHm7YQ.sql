create view CDB_TAB_IDENTITY_COLS as
  SELECT k."OWNER",k."TABLE_NAME",k."COLUMN_NAME",k."GENERATION_TYPE",k."SEQUENCE_NAME",k."IDENTITY_OPTIONS",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_TAB_IDENTITY_COLS") k
/

comment on table CDB_TAB_IDENTITY_COLS
is 'Describes all table identity columns in all containers'
/

