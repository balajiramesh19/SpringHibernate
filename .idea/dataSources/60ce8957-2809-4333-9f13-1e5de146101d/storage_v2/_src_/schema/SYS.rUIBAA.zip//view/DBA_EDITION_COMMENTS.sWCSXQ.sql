create view DBA_EDITION_COMMENTS as
  select o.name, c.comment$
from sys.obj$ o, sys.com$ c
where o.obj# = c.obj# (+)
  and o.type# = 57
/

comment on table DBA_EDITION_COMMENTS
is 'Describes comments on all editions in the database'
/

