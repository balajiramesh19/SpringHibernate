create view DBA_OBJECT_TABLES as
  select u.name, o.name,
       decode(bitand(t.property,2151678048), 0, ts.name,
              decode(t.ts#, 0, null, ts.name)),
       decode(bitand(t.property, 1024), 0, null, co.name),
       decode((bitand(t.property, 512)+bitand(t.flags, 536870912)),
              0, null, co.name),
       decode(bitand(t.trigflag, 1073741824), 1073741824, 'UNUSABLE', 'VALID'),
       decode(bitand(t.property, 32+64), 0, mod(t.pctfree$, 100), 64, 0, null),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
          decode(bitand(t.property, 32+64), 0, t.pctused$, 64, 0, null)),
       decode(bitand(t.property, 32), 0, t.initrans, null),
       decode(bitand(t.property, 32), 0, t.maxtrans, null),
       s.iniexts * ts.blocksize, s.extsize * ts.blocksize,
       s.minexts, s.maxexts,
       decode(bitand(ts.flags, 3), 1, to_number(NULL),
                                      s.extpct),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
         decode(bitand(o.flags, 2), 2, 1, decode(s.lists, 0, 1, s.lists))),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
         decode(bitand(o.flags, 2), 2, 1, decode(s.groups, 0, 1, s.groups))),
       decode(bitand(t.property, 32), 32, null,
                decode(bitand(t.flags, 32), 0, 'YES', 'NO')),
       decode(bitand(t.flags,1), 0, 'Y', 1, 'N', '?'),
       t.rowcnt,
       decode(bitand(t.property, 64), 0, t.blkcnt, null),
       decode(bitand(t.property, 64), 0, t.empcnt, null),
       t.avgspc, t.chncnt, t.avgrln, t.avgspc_flb,
       decode(bitand(t.property, 64), 0, t.flbcnt, null),
       lpad(decode(t.degree, 32767, 'DEFAULT', nvl(t.degree,1)),10),
       lpad(decode(t.instances, 32767, 'DEFAULT', nvl(t.instances,1)),10),
       lpad(decode(bitand(t.flags, 8), 8, 'Y', 'N'),5),
       decode(bitand(t.flags, 6), 0, 'ENABLED', 'DISABLED'),
       t.samplesize, t.analyzetime,
       decode(bitand(t.property, 32), 32, 'YES', 'NO'),
       decode(bitand(t.property, 64), 64, 'IOT',
               decode(bitand(t.property, 512), 512, 'IOT_OVERFLOW',
               decode(bitand(t.flags, 536870912), 536870912, 'IOT_MAPPING', null))),
       decode(bitand(t.property, 4096), 4096, 'USER-DEFINED',
                                              'SYSTEM GENERATED'),
       nvl2(ac.synobj#, su.name, tu.name),
       nvl2(ac.synobj#, so.name, ty.name),
       decode(bitand(o.flags, 2), 0, 'N', 2, 'Y', 'N'),
       decode(bitand(o.flags, 16), 0, 'N', 16, 'Y', 'N'),
       decode(bitand(t.property, 8192), 8192, 'YES', 'NO'),
       decode(bitand(o.flags, 2), 2, 'DEFAULT',
             decode(bitand(s.cachehint, 3), 1, 'KEEP', 2, 'RECYCLE',
             'DEFAULT')),
       decode(bitand(o.flags, 2), 2, 'DEFAULT',
             decode(bitand(s.cachehint, 12)/4, 1, 'KEEP', 2, 'NONE',
             'DEFAULT')),
       decode(bitand(o.flags, 2), 2, 'DEFAULT',
             decode(bitand(s.cachehint, 48)/16, 1, 'KEEP', 2, 'NONE',
             'DEFAULT')),
       decode(bitand(t.flags, 131072), 131072, 'ENABLED', 'DISABLED'),
       decode(bitand(t.flags, 512), 0, 'NO', 'YES'),
       decode(bitand(t.flags, 256), 0, 'NO', 'YES'),
       decode(bitand(o.flags, 2), 0, NULL,
          decode(bitand(t.property, 8388608), 8388608,
                 'SYS$SESSION', 'SYS$TRANSACTION')),
       decode(bitand(t.flags, 1024), 1024, 'ENABLED', 'DISABLED'),
       decode(bitand(o.flags, 2), 2, 'NO',
           decode(bitand(t.property, 2147483648), 2147483648, 'NO',
              decode(ksppcv.ksppstvl, 'TRUE', 'YES', 'NO'))),
       decode(bitand(t.property, 1024), 0, null, cu.name),
       decode(bitand(t.flags, 8388608), 8388608, 'ENABLED', 'DISABLED'),
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
          decode(bitand(ds.flags_stg, 4), 4, 'ENABLED', 'DISABLED')
       else
         decode(bitand(s.spare1, 2048), 2048, 'ENABLED', 'DISABLED')
       end,
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
          decode(bitand(ds.flags_stg, 4), 4,
          case when bitand(ds.cmpflag_stg, 3) = 1 then 'BASIC'
               when bitand(ds.cmpflag_stg, 3) = 2 then 'ADVANCED'
               else concat(decode(ds.cmplvl_stg, 1, 'QUERY LOW',
                                                 2, 'QUERY HIGH',
                                                 3, 'ARCHIVE LOW',
                                                    'ARCHIVE HIGH'),
                           decode(bitand(ds.flags_stg, 524288), 524288,
                                  ' ROW LEVEL LOCKING', '')) end,
               null)
       else
         decode(bitand(s.spare1, 2048), 0, null,
         case when bitand(s.spare1, 16777216) = 16777216
                   then 'ADVANCED'
              when bitand(s.spare1, 100663296) = 33554432  -- 0x2000000
                   then concat('QUERY LOW',
                               decode(bitand(s.spare1, 2147483648),
                                      2147483648, ' ROW LEVEL LOCKING', ''))
              when bitand(s.spare1, 100663296) = 67108864  -- 0x4000000
                   then concat('QUERY HIGH',
                               decode(bitand(s.spare1, 2147483648),
                                      2147483648, ' ROW LEVEL LOCKING', ''))
              when bitand(s.spare1, 100663296) = 100663296 -- 0x2000000+0x4000000
                   then concat('ARCHIVE LOW',
                               decode(bitand(s.spare1, 2147483648),
                                      2147483648, ' ROW LEVEL LOCKING', ''))
              when bitand(s.spare1, 134217728) = 134217728 -- 0x8000000
                   then concat('ARCHIVE HIGH',
                               decode(bitand(s.spare1, 2147483648),
                                      2147483648, ' ROW LEVEL LOCKING', ''))
              else 'BASIC' end)
       end,
       decode(bitand(o.flags, 128), 128, 'YES', 'NO'),
       decode(bitand(t.property, 17179869184), 17179869184, 'NO',
              decode(bitand(t.property, 32), 32, 'N/A', 'YES')),
       -- INMEMORY
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 2147483648 ) = 2147483648) then
         decode(bitand(xt.property,16), 16, 'ENABLED', 'DISABLED')
       when (bitand(t.property, 17179869184) = 17179869184) then
         -- flags/imcflag_stg (stgdef.h)
         decode(bitand(ds.flags_stg, 6291456),
             2097152, 'ENABLED',
             4194304, 'DISABLED', 'DISABLED')
       else
         -- ktsscflg (ktscts.h)
         decode(bitand(s.spare1, 70373039144960),
             4294967296,     'ENABLED',
             70368744177664, 'DISABLED', 'DISABLED')
       end,
       -- INMEMORY_PRIORITY
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 4), 4,
                decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 7936),
                256, 'NONE',
                512, 'LOW',
                1024, 'MEDIUM',
                2048, 'HIGH',
                4096, 'CRITICAL', 'UNKNOWN'), null),
                'NONE'),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 34359738368), 34359738368,
                decode(bitand(s.spare1, 61572651155456),
                8796093022208, 'LOW',
                17592186044416, 'MEDIUM',
                35184372088832, 'HIGH',
                52776558133248, 'CRITICAL', 'NONE'),
                'NONE'),
                null)
       end,
       -- INMEMORY_DISTRIBUTE
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 1), 1,
                       decode(bitand(ds.imcflag_stg, (16+32)),
                              16,  'BY ROWID RANGE',
                              32,  'BY PARTITION',
                              48,  'BY SUBPARTITION',
                               0,  'AUTO'),
                  null), null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 8589934592), 8589934592,
                        decode(bitand(s.spare1, 206158430208),
                        68719476736,   'BY ROWID RANGE',
                        137438953472,  'BY PARTITION',
                        206158430208,  'BY SUBPARTITION',
                        0,             'AUTO'),
                        'UNKNOWN'),
                  null)
       end,
       -- INMEMORY_COMPRESSION
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 2147483648 ) = 2147483648) then
             decode(bitand(xt.property, (16+32+64+128)),
                         (16+32), 'NO MEMCOMPRESS',
                         (16+64), 'FOR DML',
                      (16+32+64), 'FOR QUERY LOW',
                        (16+128), 'FOR QUERY HIGH',
                     (16+128+32), 'FOR CAPACITY LOW',
                     (16+128+64), 'FOR CAPACITY HIGH', NULL)
       when (bitand(t.property, 17179869184) = 17179869184) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, (2+8+64+128)),
                              2,   'NO MEMCOMPRESS',
                              8,  'FOR DML',
                              10,  'FOR QUERY LOW',
                              64, 'FOR QUERY HIGH',
                              66, 'FOR CAPACITY LOW',
                              72, 'FOR CAPACITY HIGH', 'UNKNOWN'),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 841813590016),
                              17179869184,  'NO MEMCOMPRESS',
                              274877906944, 'FOR DML',
                              292057776128, 'FOR QUERY LOW',
                              549755813888, 'FOR QUERY HIGH',
                              566935683072, 'FOR CAPACITY LOW',
                              824633720832, 'FOR CAPACITY HIGH', 'UNKNOWN'),
                 null)
       end,
       -- INMEMORY_DUPLICATE
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
        decode(bitand(ds.flags_stg, 2097152), 2097152,
               decode(bitand(ds.imcflag_stg, (8192+16384)),
                              8192,   'NO DUPLICATE',
                              16384,  'DUPLICATE',
                              24576,  'DUPLICATE ALL',
                              'UNKNOWN'),
                null)
       else
          decode(bitand(s.spare1, 4294967296), 4294967296,
                   decode(bitand(s.spare1, 6597069766656),
                           2199023255552, 'NO DUPLICATE',
                           4398046511104, 'DUPLICATE',
                           6597069766656, 'DUPLICATE ALL', 'UNKNOWN'),
                 null)
       end,
       decode(bitand(t.property, 2147483648), 2147483648, 'YES', 'NO'),
       -- CELLMEMORY
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
         -- deferred segment: stgccflags (stgdef.h)
         decode(ccflag_stg,
             8194, 'NO MEMCOMPRESS',
             8196, 'FOR QUERY',
             8200, 'FOR CAPACITY',
             16384, 'DISABLED', null)
       else
         -- created segment: ktsscflg (ktscts.h)
         decode(bitand(s.spare1, 4362862139015168),
              281474976710656, 'DISABLED',
              703687441776640, 'NO MEMCOMPRESS',
             1266637395197952, 'MEMCOMPRESS FOR QUERY',
             2392537302040576, 'MEMCOMPRESS FOR CAPACITY', null)
       end,
       -- INMEMORY_SERVICE
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 32768), 32768,
                       decode(bitand(svc.svcflags, 7),
                              0, null,
                              1, 'DEFAULT',
                              2, 'NONE',
                              3, 'ALL',
                              4, 'USER_DEFINED', 'UNKNOWN'), 'DEFAULT'),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 9007199254740992), 9007199254740992,
                       decode(bitand(svc.svcflags, 7),
                              0, null,
                              1, 'DEFAULT',
                              2, 'NONE',
                              3, 'ALL',
                              4, 'USER_DEFINED', 'UNKNOWN'), 'DEFAULT'),
                 null)
       end,
       -- INMEMORY_SERVICE_NAME
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 32768), 32768,
                       svc.svcname, null),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 9007199254740992), 9007199254740992,
                       svc.svcname, null),
                null)
       end,
       -- MEMOPTIMIZE_READ
       case when bitand(t.property, 32) = 32
              then 'N/A'
       else
          decode(bitand(t.property, power(2,91)), power(2,91),
                        'ENABLED', 'DISABLED')
       end,
       -- MEMOPTIMIZE_WRITE
       case when bitand(t.property, 32) = 32
              then 'N/A'
       else
          decode(bitand(t.property, power(2,92)), power(2,92),
                        'ENABLED', 'DISABLED')
       end,
        -- HAS_SENSITIVE_COLUMN
       decode(bitand(t.property, power(2,89)), power(2,89), 'YES', 'NO')
from sys.user$ u, sys.ts$ ts, sys.seg$ s, sys.obj$ co, sys.tab$ t, sys.obj$ o,
     sys.external_tab$ xt, sys.coltype$ ac, sys.obj$ ty, sys."_BASE_USER" tu,
     sys.col$ tc, sys.obj$ cx, sys.user$ cu, sys.obj$ so, sys."_BASE_USER" su,
     x$ksppcv ksppcv, x$ksppi ksppi, sys.deferred_stg$ ds, sys.imsvc$ svc
where o.owner# = u.user#
  and o.obj# = t.obj#
  and t.obj# = xt.obj# (+)
  and bitand(t.property, 1) = 1
  and bitand(o.flags, 128) = 0
  and t.obj# = tc.obj#
  and tc.name = 'SYS_NC_ROWINFO$'
  and tc.obj# = ac.obj#
  and tc.intcol# = ac.intcol#
  and ac.toid = ty.oid$
  and ty.owner# = tu.user#
  and ty.type# <> 10
  and t.bobj# = co.obj# (+)
  and t.ts# = ts.ts#
  and t.file# = s.file# (+)
  and t.block# = s.block# (+)
  and t.ts# = s.ts# (+)
  and t.obj# = ds.obj# (+)
  and t.dataobj# = cx.obj# (+)
  and cx.owner# = cu.user# (+)
  and ac.synobj# = so.obj# (+)
  and so.owner# = su.user# (+)
  and ksppi.indx = ksppcv.indx
  and ksppi.ksppinm = '_dml_monitoring_enabled'
  and t.obj# = svc.obj# (+)
  and svc.subpart#(+) is null
/

comment on table DBA_OBJECT_TABLES
is 'Description of all object tables in the database'
/

