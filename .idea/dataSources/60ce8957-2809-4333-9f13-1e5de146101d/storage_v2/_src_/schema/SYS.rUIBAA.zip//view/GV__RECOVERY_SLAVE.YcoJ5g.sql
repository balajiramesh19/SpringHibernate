create view GV_$RECOVERY_SLAVE as
  select "INST_ID","START_TIME","TYPE","ITEM","UNITS","SOFAR","TOTAL","COMMENTS","CON_ID" from gv$recovery_slave
/

