create view GV_$DIAG_APP_TRACE_FILE as
  select "INST_ID","ADR_HOME","TRACE_FILENAME","CHANGE_TIME","MODIFY_TIME","SQL_TRACE","OPTIMIZER_TRACE","CON_ID" from gv$diag_app_trace_file
/

