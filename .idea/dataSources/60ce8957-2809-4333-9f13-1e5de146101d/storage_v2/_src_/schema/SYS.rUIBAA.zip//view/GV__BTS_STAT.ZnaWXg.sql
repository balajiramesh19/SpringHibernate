create view GV_$BTS_STAT as
  select "INST_ID","TSN","TSV","MAXSIZE","CURSIZE","USED","UTIME","DALLOC","DFREE","NALLOC","NFREE","DTIME","TALLOC","TFREE","TTIME","FLAG","CON_ID" from gv$bts_stat
/

