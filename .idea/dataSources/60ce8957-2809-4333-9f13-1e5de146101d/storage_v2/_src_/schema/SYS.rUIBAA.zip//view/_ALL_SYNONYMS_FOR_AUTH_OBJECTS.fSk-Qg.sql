create view "_ALL_SYNONYMS_FOR_AUTH_OBJECTS" as
  select OWNER, SYNONYM_NAME, BASE_OBJ_OWNER, BASE_OBJ_NAME, ORIGIN_CON_ID
from "_INT$_ALL_SYNONYMS_FOR_AO"
where
      ora_check_sys_privilege ( ownerid, object_type#) = 1
   or
      exists
        (select null
         from sys.objauth$ ba, sys."_CURRENT_EDITION_OBJ" bo, sys.user$ bu
         where bu.name = BASE_OBJ_OWNER
           and bo.name = BASE_OBJ_NAME
           and bu.user# = bo.owner#
           and ba.obj# = bo.obj#
           and (   ba.grantee# in (select kzsrorol from x$kzsro)
                or ba.grantor# = USERENV('SCHEMAID')
               )
        )
/

