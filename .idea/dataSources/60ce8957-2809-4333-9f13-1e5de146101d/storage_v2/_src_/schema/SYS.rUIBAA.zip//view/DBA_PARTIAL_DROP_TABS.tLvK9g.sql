create view DBA_PARTIAL_DROP_TABS as
  select u.name, o.name
from sys.user$ u, sys.obj$ o, sys.tab$ t
where t.obj# = o.obj#
      and bitand(t.flags,32768) = 32768
      and u.user# = o.owner#
      group by u.name, o.name
/

comment on table DBA_PARTIAL_DROP_TABS
is 'All tables with partially dropped columns in the database'
/

