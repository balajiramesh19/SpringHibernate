create view GV_$DATABASE_REPLAY_PROGRESS as
  select "INST_ID","STAT_ID","STAT_TYPE","STAT_NAME","VALUE","CON_ID" from gv$database_replay_progress
/

