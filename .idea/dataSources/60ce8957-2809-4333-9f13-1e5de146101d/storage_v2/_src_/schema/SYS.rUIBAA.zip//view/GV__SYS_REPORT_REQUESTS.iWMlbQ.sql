create view GV_$SYS_REPORT_REQUESTS as
  select "INST_ID","CON_ID","REPORT_CLASS","REPORT_REF","REF_LEN","PRIORITY","GENERATION_TIME" from gv$sys_report_requests
/

