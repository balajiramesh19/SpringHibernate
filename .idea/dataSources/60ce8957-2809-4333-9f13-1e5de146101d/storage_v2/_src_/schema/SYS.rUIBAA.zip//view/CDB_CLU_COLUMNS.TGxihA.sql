create view CDB_CLU_COLUMNS as
  SELECT k."OWNER",k."CLUSTER_NAME",k."CLU_COLUMN_NAME",k."TABLE_NAME",k."TAB_COLUMN_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_CLU_COLUMNS") k
/

comment on table CDB_CLU_COLUMNS
is 'Mapping of table columns to cluster columns in all containers'
/

