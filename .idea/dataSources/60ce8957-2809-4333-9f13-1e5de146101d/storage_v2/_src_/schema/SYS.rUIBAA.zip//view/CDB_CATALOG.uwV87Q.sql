create view CDB_CATALOG as
  SELECT k."OWNER",k."TABLE_NAME",k."TABLE_TYPE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_CATALOG") k
/

comment on table CDB_CATALOG
is 'All database Tables, Views, Synonyms, Sequences in all containers'
/

