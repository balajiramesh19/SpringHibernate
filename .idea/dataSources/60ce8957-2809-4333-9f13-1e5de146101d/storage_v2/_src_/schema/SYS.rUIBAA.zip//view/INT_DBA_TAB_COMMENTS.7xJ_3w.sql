create view INT$DBA_TAB_COMMENTS as
  select u.name, u.user#, o.name, o.obj#, o.type#,
       decode(o.type#, 0, 'NEXT OBJECT', 1, 'INDEX', 2, 'TABLE', 3, 'CLUSTER',
                      4, 'VIEW', 5, 'SYNONYM', 150, 'HIERARCHY', 152, 'ANALYTIC VIEW', 'UNDEFINED'),
       c.comment$,
       case when bitand(o.flags, (65536+131072+4294967296))>0 then 1 else 0 end,
       to_number(sys_context('USERENV', 'CON_ID')),
       /* Bug 19552209: Add APPLICATION column for application object */
       case when bitand(o.flags, 134217728)>0 then 1 else 0 end
from sys."_CURRENT_EDITION_OBJ" o, sys.user$ u, sys.com$ c
where o.owner# = u.user#
  and o.linkname is null
  and (o.type# in (4)                                                /* view */
       or o.type# in (150)                                           /* hierarchy */
       or o.type# in (152)                                           /* analytic view */
       or
       (o.type# = 2                                                /* tables */
        AND         /* excluding iot-overflow, nested or mv container tables */
        not exists (select null
                      from sys.tab$ t
                     where t.obj# = o.obj#
                       and (bitand(t.property, 512) = 512 or
                            bitand(t.property, 8192) = 8192 OR
                            bitand(t.property, 67108864) = 67108864))))
  and o.obj# = c.obj#(+)
  and c.col#(+) is null
  and (SYS_CONTEXT('USERENV', 'CON_ID') = 0 or
          (SYS_CONTEXT('USERENV','IS_APPLICATION_ROOT') = 'YES' and
           bitand(o.flags, 4194304)<>4194304) or
          SYS_CONTEXT('USERENV','IS_APPLICATION_ROOT') = 'NO')
/

