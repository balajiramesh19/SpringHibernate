create view V_$DATABASE_REPLAY_PROGRESS as
  select "STAT_ID","STAT_TYPE","STAT_NAME","VALUE","CON_ID" from v$database_replay_progress
/

