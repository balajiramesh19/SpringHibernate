create view V_$PROCESS_POOL as
  select "POOL_NAME","ENABLED","MIN_COUNT","BATCH_COUNT","INIT_COUNT","CUR_COUNT","MAX_COUNT","CON_ID" from v$process_pool
/

