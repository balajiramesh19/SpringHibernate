create view CDB_SYNONYMS as
  SELECT k."OWNER",k."SYNONYM_NAME",k."TABLE_OWNER",k."TABLE_NAME",k."DB_LINK",k."ORIGIN_CON_ID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_SYNONYMS") k
/

comment on table CDB_SYNONYMS
is 'All synonyms in the database in all containers'
/

