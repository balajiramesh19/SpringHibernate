create view V_$IM_GLOBALDICT_SORTORDER as
  select "CON_ID","HEAD_ADDRESS","VERSION_ID","START_CODE","NUM_SYMBOLS","TOTAL_LENGTH","FLAGS","SPARE" from v$im_globaldict_sortorder
/

