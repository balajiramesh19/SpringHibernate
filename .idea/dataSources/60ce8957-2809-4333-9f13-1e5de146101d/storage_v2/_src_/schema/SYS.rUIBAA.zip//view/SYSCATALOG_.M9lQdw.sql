create view SYSCATALOG_ as
  select o.name, u.name, o.owner#,
         decode(o.type#, 2, 'TABLE', 4, 'VIEW', 6, 'SEQUENCE','?'), c.comment$
  from  sys.user$ u, sys."_CURRENT_EDITION_OBJ" o, sys.com$ c
  where u.user# = o.owner#
  and (o.type# in (4, 6, 150, 152)     /* view, sequence, hierarchies and analytic views */
       or
       (o.type# = 2     /* tables, excluding iot - overflow and nested tables */
        and
        not exists (select null
                      from sys.tab$ t
                     where t.obj# = o.obj#
                       and (bitand(t.property, 512) = 512 or
                            bitand(t.property, 8192) = 8192))))
    and o.linkname is null
    and o.obj# = c.obj#(+)
    and ( o.owner# = userenv('SCHEMAID')
          or o.obj# in
             (select oa.obj#
              from   sys.objauth$ oa
              where  oa.grantee# in (userenv('SCHEMAID'), 1)
              )
          or
          (
            (o.type# in (4,6,150,152) /* view, sequence, hierarchies and analytic views */
             or
             (o.type# = 2 /* tables, excluding iot-overflow and nested tables */
              and
              not exists (select null
                            from sys.tab$ t
                           where t.obj# = o.obj#
                             and (bitand(t.property, 512) = 512 or
                                  bitand(t.property, 8192) = 8192))))
          and
          /* user has system privileges */
           ora_check_sys_privilege ( o.owner#, o.type# ) = 1
          )
       )
/

