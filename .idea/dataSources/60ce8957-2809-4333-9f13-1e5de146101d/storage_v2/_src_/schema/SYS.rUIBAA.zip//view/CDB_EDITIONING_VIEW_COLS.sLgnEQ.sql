create view CDB_EDITIONING_VIEW_COLS as
  SELECT k."OWNER",k."VIEW_NAME",k."VIEW_COLUMN_ID",k."VIEW_COLUMN_NAME",k."TABLE_COLUMN_ID",k."TABLE_COLUMN_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_EDITIONING_VIEW_COLS") k
/

comment on table CDB_EDITIONING_VIEW_COLS
is 'Relationship between columns of all Editioning Views in the database and the table columns to which they map in all containers'
/

