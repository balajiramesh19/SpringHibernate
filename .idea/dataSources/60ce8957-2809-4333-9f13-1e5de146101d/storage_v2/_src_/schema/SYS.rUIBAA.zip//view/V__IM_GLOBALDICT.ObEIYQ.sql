create view V_$IM_GLOBALDICT as
  select "CON_ID","DOMAIN#","HEAD_ADDRESS","LASTFREE","FLAGS","SPARE","REFCOUNT" from v$im_globaldict
/

