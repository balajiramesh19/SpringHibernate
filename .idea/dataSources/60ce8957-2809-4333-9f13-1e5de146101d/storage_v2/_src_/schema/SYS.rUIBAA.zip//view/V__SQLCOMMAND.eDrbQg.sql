create view V_$SQLCOMMAND as
  select "COMMAND_TYPE","COMMAND_NAME","CON_ID" from v$sqlcommand
/

