create view GV_$QUARANTINE as
  select "INST_ID","OBJECT","ADDRESS","BYTES","ERROR","TIMESTAMP","CON_ID" from gv$quarantine
/

