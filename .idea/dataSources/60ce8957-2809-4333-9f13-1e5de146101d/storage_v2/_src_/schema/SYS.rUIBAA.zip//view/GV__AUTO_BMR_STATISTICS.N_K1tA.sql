create view GV_$AUTO_BMR_STATISTICS as
  select "INST_ID","FILE#","BLOCK#","CORRUPTION_CHANGE#","FIXED_TIME","ERROR_CODE","ERROR_MESSAGE","CON_ID" from gv$auto_bmr_statistics
/

