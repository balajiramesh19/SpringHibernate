create view V_$IM_SEG_EXT_MAP as
  select "EXT_ADDR","EXT_LEN","START_DBA","SLEN","NUMA_ID","FREENESS","TYPE","STRP_CTRL_ID","STRP_BLK_ID","POOL_ID","CON_ID" from v$im_seg_ext_map
/

