create view V_$DIAG_APP_TRACE_FILE as
  select "ADR_HOME","TRACE_FILENAME","CHANGE_TIME","MODIFY_TIME","SQL_TRACE","OPTIMIZER_TRACE","CON_ID" from v$diag_app_trace_file
/

