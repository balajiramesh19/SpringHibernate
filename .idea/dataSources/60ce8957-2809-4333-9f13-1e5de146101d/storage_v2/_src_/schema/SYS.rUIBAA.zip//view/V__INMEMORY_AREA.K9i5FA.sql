create view V_$INMEMORY_AREA as
  select "POOL","ALLOC_BYTES","USED_BYTES","POPULATE_STATUS","CON_ID" from v$inmemory_area
/

