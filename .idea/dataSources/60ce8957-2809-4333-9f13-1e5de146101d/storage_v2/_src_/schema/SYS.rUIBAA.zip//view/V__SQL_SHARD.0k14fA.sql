create view V_$SQL_SHARD as
  select "SQL_ID","CHILD_NUMBER","OPERATION_ID","SHARD_SQL_ID","SHARD_ID","SHARD_CHILD_NUMBER","CON_ID" from v$sql_shard
/

