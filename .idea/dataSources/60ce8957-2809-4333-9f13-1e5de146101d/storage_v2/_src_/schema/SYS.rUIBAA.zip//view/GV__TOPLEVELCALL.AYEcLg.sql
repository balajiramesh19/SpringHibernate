create view GV_$TOPLEVELCALL as
  select "INST_ID","TOP_LEVEL_CALL#","TOP_LEVEL_CALL_NAME","CON_ID" from gv$toplevelcall
/

