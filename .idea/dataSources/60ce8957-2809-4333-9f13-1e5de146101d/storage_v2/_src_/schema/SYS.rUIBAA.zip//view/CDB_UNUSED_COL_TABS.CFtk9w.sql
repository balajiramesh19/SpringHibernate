create view CDB_UNUSED_COL_TABS as
  SELECT k."OWNER",k."TABLE_NAME",k."COUNT",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_UNUSED_COL_TABS") k
/

comment on table CDB_UNUSED_COL_TABS
is 'All tables with unused columns in the database in all containers'
/

