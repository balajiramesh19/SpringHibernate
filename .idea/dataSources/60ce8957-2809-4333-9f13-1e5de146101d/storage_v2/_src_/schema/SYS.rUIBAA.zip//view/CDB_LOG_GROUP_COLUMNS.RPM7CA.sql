create view CDB_LOG_GROUP_COLUMNS as
  SELECT k."OWNER",k."LOG_GROUP_NAME",k."TABLE_NAME",k."COLUMN_NAME",k."POSITION",k."LOGGING_PROPERTY",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_LOG_GROUP_COLUMNS") k
/

comment on table CDB_LOG_GROUP_COLUMNS
is 'Information about columns in log group definitions in all containers'
/

