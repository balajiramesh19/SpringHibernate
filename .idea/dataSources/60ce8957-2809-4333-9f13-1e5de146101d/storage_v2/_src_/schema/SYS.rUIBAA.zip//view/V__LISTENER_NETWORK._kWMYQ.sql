create view V_$LISTENER_NETWORK as
  select "NETWORK","TYPE","VALUE","CON_ID" from v$listener_network
/

