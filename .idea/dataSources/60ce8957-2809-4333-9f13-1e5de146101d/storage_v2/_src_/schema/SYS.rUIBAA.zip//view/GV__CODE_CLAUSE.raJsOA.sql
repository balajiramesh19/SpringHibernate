create view GV_$CODE_CLAUSE as
  select "INST_ID","CODE_ID#","CLAUSE_ID#","CLAUSE_NAME","PARAMETER_NAME","CON_ID" from gv$code_clause
/

