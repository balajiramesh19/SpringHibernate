create view V_$DML_STATS as
  select "OBJN","INS","UPD","DEL","DROPSEG","CURROWS","PAROBJN","LASTUSED","FLAGS","CON_ID" from v$dml_stats
/

