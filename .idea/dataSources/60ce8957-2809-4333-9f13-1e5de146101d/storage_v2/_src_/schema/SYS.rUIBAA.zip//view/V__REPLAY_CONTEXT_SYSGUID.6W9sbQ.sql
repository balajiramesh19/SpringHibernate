create view V_$REPLAY_CONTEXT_SYSGUID as
  select "CONTEXT_ID","SYSGUID_VALUE","REPLAYED","CON_ID" from v$replay_context_sysguid
/

