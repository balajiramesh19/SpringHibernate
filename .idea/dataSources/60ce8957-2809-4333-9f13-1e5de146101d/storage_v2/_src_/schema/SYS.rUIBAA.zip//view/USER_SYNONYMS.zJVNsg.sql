create view USER_SYNONYMS as
  select SYNONYM_NAME, TABLE_OWNER, TABLE_NAME, DB_LINK,
          ORIGIN_CON_ID
from NO_ROOT_SW_FOR_LOCAL(INT$DBA_SYNONYMS)
where OWNER=SYS_CONTEXT('USERENV', 'CURRENT_USER')
/

comment on table USER_SYNONYMS
is 'The user''s private synonyms'
/

