create view CDB_DDL_LOCKS as
  SELECT k."SESSION_ID",k."OWNER",k."NAME",k."TYPE",k."MODE_HELD",k."MODE_REQUESTED",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_DDL_LOCKS") k
/

comment on table CDB_DDL_LOCKS
is ' in all containers'
/

