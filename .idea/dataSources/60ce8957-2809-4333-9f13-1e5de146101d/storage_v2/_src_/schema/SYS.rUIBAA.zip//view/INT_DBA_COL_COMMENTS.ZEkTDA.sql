create view INT$DBA_COL_COMMENTS as
  select u.name, u.user#, o.name, o.obj#, o.type#, c.name, co.comment$,
       case when bitand(o.flags, (65536+131072+4294967296))>0 then 1 else 0 end,
       to_number(sys_context('USERENV', 'CON_ID')),
       /* Bug 19552209: Add APPLICATION column for application object */
       case when bitand(o.flags, 134217728)>0 then 1 else 0 end
from sys."_CURRENT_EDITION_OBJ" o, sys.col$ c, sys.user$ u, sys.com$ co
where o.owner# = u.user#
  and o.type# in (2, 4)
  and o.obj# = c.obj#
  and c.obj# = co.obj#(+)
  and c.intcol# = co.col#(+)
  and bitand(c.property, 32) = 0 /* not hidden column */
  and (SYS_CONTEXT('USERENV', 'CON_ID') = 0 or
          (SYS_CONTEXT('USERENV','IS_APPLICATION_ROOT') = 'YES' and
           bitand(o.flags, 4194304)<>4194304) or
          SYS_CONTEXT('USERENV','IS_APPLICATION_ROOT') = 'NO')
/

