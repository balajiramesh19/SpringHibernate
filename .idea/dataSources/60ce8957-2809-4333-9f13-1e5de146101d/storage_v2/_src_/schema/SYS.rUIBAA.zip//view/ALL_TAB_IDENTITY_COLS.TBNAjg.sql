create view ALL_TAB_IDENTITY_COLS as
  select u.name, o.name, c.name,
       decode(bitand(c.property, 137438953472 + 274877906944),
                     137438953472, 'ALWAYS',
                     274877906944, 'BY DEFAULT'),
       so.name,
       'START WITH: '     || i.startwith ||
       ', INCREMENT BY: ' || s.increment$ ||
       ', MAX_VALUE: '    || s.maxvalue ||
       ', MIN_VALUE: '    || s.minvalue ||
       ', CYCLE_FLAG: '   || decode (s.cycle#, 0, 'N', 1, 'Y') ||
       ', CACHE_SIZE: '   || s.cache ||
       ', ORDER_FLAG: '   || decode (s.order$, 0, 'N', 1, 'Y')  ||
       ', SCALE_FLAG: '   || decode (bitand(s.flags, 16), 16, 'Y', 'N') ||
       ', EXTEND_FLAG: '  || decode (bitand(s.flags, 2048), 2048, 'Y', 'N') ||
       ', SESSION_FLAG: ' || decode(bitand(s.flags, 64), 64, 'Y', 'N') ||
       ', KEEP_VALUE: '   || decode(bitand(s.flags, 512), 512, 'Y', 'N')
from sys.idnseq$ i, sys.obj$ o, sys.user$ u, sys.col$ c,
     sys.seq$ s, sys.obj$ so
where o.owner# = u.user#
and o.obj# = i.obj#
and c.intcol# = i.intcol#
and c.obj# = i.obj#
and s.obj# = i.seqobj#
and so.obj# = i.seqobj#
and (o.owner# = userenv('SCHEMAID')
     or o.obj# in
          (select oa.obj#
           from sys.objauth$ oa
           where grantee# in ( select kzsrorol
                               from x$kzsro
                             )
          )
     or /* user has system privileges */
     ora_check_sys_privilege ( o.owner#, o.type# ) = 1
    )
/

comment on table ALL_TAB_IDENTITY_COLS
is 'Describes all table identity columns'
/

