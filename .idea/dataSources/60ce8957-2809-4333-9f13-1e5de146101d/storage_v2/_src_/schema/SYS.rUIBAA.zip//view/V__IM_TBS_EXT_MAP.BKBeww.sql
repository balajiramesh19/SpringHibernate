create view V_$IM_TBS_EXT_MAP as
  select "START_DBA","END_DBA","DATAOBJ","IMCU_ADDR","LEN","SMU_ADDR","CON_ID" from v$im_tbs_ext_map
/

