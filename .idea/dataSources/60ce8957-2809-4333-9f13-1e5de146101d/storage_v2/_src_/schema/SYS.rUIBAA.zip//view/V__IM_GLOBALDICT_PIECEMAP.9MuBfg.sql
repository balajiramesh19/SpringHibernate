create view V_$IM_GLOBALDICT_PIECEMAP as
  select "CON_ID","HEAD_ADDRESS","PMAP_HEAD_ADDRESS","TYPE","CHUNK_ID","CHUNK_ALLOCATED","CHUNK_USED","FLAGS","SPARE" from v$im_globaldict_piecemap
/

