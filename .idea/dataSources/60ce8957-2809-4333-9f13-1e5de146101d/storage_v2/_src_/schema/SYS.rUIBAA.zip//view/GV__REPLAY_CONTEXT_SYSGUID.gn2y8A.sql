create view GV_$REPLAY_CONTEXT_SYSGUID as
  select "INST_ID","CONTEXT_ID","SYSGUID_VALUE","REPLAYED","CON_ID" from gv$replay_context_sysguid
/

