create view GV_$EXADIRECT_ACL as
  select "INST_ID","SERVICE_NAME","SGID","CON_ID" from gv$exadirect_acl
/

