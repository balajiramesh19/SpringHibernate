create view V_$TSDP_SUPPORTED_FEATURE as
  select "FEATURE_NAME","FUNCTIONALITY","COMMENTS$","CON_ID" from v$tsdp_supported_feature
/

