create view GV_$QPX_INVENTORY as
  select "INST_ID","NODE_NAME","PATCHES","CON_ID" from gv$qpx_inventory
/

