create view GV_$EXP_STATS as
  select "INST_ID","EXPID","OBJNUM","DYNCOST","EVALCNT","CON_ID" from gv$exp_stats
/

