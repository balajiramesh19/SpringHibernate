create view GV_$SQL_SHARD as
  select "INST_ID","SQL_ID","CHILD_NUMBER","OPERATION_ID","SHARD_SQL_ID","SHARD_ID","SHARD_CHILD_NUMBER","CON_ID" from gv$sql_shard
/

