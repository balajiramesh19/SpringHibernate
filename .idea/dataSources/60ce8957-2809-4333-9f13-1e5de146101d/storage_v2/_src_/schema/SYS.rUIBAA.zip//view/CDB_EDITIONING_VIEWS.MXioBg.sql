create view CDB_EDITIONING_VIEWS as
  SELECT k."OWNER",k."VIEW_NAME",k."TABLE_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_EDITIONING_VIEWS") k
/

comment on table CDB_EDITIONING_VIEWS
is 'Description of all Editioning Views in the database in all containers'
/

