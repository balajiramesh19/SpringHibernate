create view "_INT$_ALL_SYNONYMS_FOR_AO" as
  select s.obj#, u.name, u.user#, o.name, o.type#, s.owner, s.name, s.node,
       case when bitand(o.flags, (65536+131072+4294967296))>0 then 1 else 0 end,
       to_number(sys_context('USERENV', 'CON_ID'))
from  sys.user$ u, sys.syn$ s, sys."_CURRENT_EDITION_OBJ" o,
      sys."_CURRENT_EDITION_OBJ" bo, sys.user$ bu
where o.obj# = s.obj#
  and o.type# = 5
  and o.owner# = u.user#
  and s.node is null
  and bo.name = s.name
  and bo.owner# = bu.user#
  and bu.name = s.owner
  and bo.type# <> 5
/

