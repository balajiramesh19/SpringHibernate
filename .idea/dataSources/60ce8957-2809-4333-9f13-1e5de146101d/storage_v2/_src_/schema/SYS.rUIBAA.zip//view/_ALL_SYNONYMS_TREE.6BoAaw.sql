create view "_ALL_SYNONYMS_TREE" as
  select s.syn_owner, s.syn_synonym_name, s.syn_table_owner,
       s.syn_table_name, s.syn_db_link, s.origin_con_id
from sys."_ALL_SYNONYMS_FOR_SYNONYMS" s
/* user has any privs on ultimate base object */
start with exists (
  select /*+ NO_PUSH_SUBQ */ null
  from sys."_ALL_SYNONYMS_FOR_AUTH_OBJECTS" sa
  where s.syn_table_owner = sa.owner
    and s.syn_table_name = sa.synonym_name
  )
connect by nocycle prior s.syn_owner = s.syn_table_owner and
                   prior s.syn_synonym_name = s.syn_table_name
/

