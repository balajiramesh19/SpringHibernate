create view GV_$IP_ACL as
  select "INST_ID","SERVICE_NAME","HOST","CON_ID" from gv$ip_acl
/

