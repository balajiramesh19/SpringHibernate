create view V_$CON_SYS_TIME_MODEL as
  select "STAT_ID","STAT_NAME","VALUE","CON_ID" from v$con_sys_time_model
/

