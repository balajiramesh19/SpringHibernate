create view DBA_COL_COMMENTS as
  select OWNER, TABLE_NAME, COLUMN_NAME, COMMENTS, ORIGIN_CON_ID
from INT$DBA_COL_COMMENTS
/

comment on table DBA_COL_COMMENTS
is 'Comments on columns of all tables and views'
/

