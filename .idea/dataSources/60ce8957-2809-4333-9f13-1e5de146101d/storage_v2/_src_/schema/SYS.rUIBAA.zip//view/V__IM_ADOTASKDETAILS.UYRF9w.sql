create view V_$IM_ADOTASKDETAILS as
  select "TASK_ID","OBJ#","ACTION","STATUS","CON_ID" from v$im_adotaskdetails
/

