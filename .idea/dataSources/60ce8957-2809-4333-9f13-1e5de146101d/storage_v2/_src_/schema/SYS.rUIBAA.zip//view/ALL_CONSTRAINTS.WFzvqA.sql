create view ALL_CONSTRAINTS as
  select OWNER, CONSTRAINT_NAME, CONSTRAINT_TYPE,
       TABLE_NAME, SEARCH_CONDITION, SEARCH_CONDITION_VC,
       R_OWNER, R_CONSTRAINT_NAME, DELETE_RULE, STATUS,
       DEFERRABLE, DEFERRED, VALIDATED, GENERATED,
       BAD, RELY, LAST_CHANGE, INDEX_OWNER, INDEX_NAME,
       INVALID, VIEW_RELATED, ORIGIN_CON_ID
from INT$DBA_CONSTRAINTS
where (OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OBJ_ID(OWNER, TABLE_NAME, OBJECT_TYPE#, OBJECT_ID) in
          (select obj# from sys.objauth$
                       where grantee# in ( select kzsrorol
                                           from x$kzsro
                                         )
          )
        or /* user has system privileges */
        ora_check_sys_privilege ( ownerid, object_type# ) = 1
      )
/

comment on table ALL_CONSTRAINTS
is 'Constraint definitions on accessible tables'
/

