create view DBA_ROLE_PRIVS as
  select decode(sa.grantee#, 1, 'PUBLIC', u1.name), u2.name,
       decode(min(bitand(nvl(option$, 0), 1)), 1, 'YES', 'NO'),
       decode(min(bitand(nvl(option$, 0), 2)), 2, 'YES', 'NO'),
       decode(min(u1.defrole), 0, 'NO',
              1, decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'),'NO'),
              2, decode(min(ud.role#), NULL, 'NO', decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO')),
              3, decode(min(ud.role#), NULL, decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO'), 'NO'), 'NO'),
       'NO', 'NO'
from sysauth$ sa, user$ u1, user$ u2, defrole$ ud
where sa.grantee#=ud.user#(+)
  and sa.privilege#=ud.role#(+) and u1.user#=sa.grantee#
  and u2.user#=sa.privilege#
  and bitand(nvl(option$, 0), 4) = 0
group by decode(sa.grantee#,1,'PUBLIC',u1.name),u2.name
union all
/* Commonly granted Privileges */
select decode(sa.grantee#, 1, 'PUBLIC', u1.name), u2.name,
       decode(min(bitand(nvl(option$, 0), 16)), 16, 'YES', 'NO'),
       decode(min(bitand(nvl(option$, 0), 32)), 32, 'YES', 'NO'),
       decode(min(u1.defrole), 0, 'NO',
              1, decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'),'NO'),
              2, decode(min(ud.role#), NULL, 'NO', decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO')),
              3, decode(min(ud.role#), NULL, decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO'), 'NO'), 'NO'),
       'YES', decode(SYS_CONTEXT('USERENV', 'CON_ID'), 1, 'NO', 'YES')
from sysauth$ sa, user$ u1, user$ u2, defrole$ ud
where sa.grantee#=ud.user#(+)
  and sa.privilege#=ud.role#(+) and u1.user#=sa.grantee#
  and u2.user#=sa.privilege#
  and bitand(nvl(option$, 0), 8) = 8
group by decode(sa.grantee#,1,'PUBLIC',u1.name),u2.name
union all
/* Federationally granted Privileges */
select decode(sa.grantee#, 1, 'PUBLIC', u1.name), u2.name,
       decode(min(bitand(nvl(option$, 0), 128)), 128, 'YES', 'NO'),
       decode(min(bitand(nvl(option$, 0), 256)), 256, 'YES', 'NO'),
       decode(min(u1.defrole), 0, 'NO',
              1, decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'),'NO'),
              2, decode(min(ud.role#), NULL, 'NO', decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO')),
              3, decode(min(ud.role#), NULL, decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO'), 'NO'), 'NO'),
       'YES',
       decode(SYS_CONTEXT('USERENV', 'IS_APPLICATION_PDB'), 'YES', 'YES', 'NO')
from sysauth$ sa, user$ u1, user$ u2, defrole$ ud
where sa.grantee#=ud.user#(+)
  and sa.privilege#=ud.role#(+) and u1.user#=sa.grantee#
  and u2.user#=sa.privilege#
  and bitand(nvl(option$, 0), 64) = 64
group by decode(sa.grantee#,1,'PUBLIC',u1.name),u2.name
/

comment on table DBA_ROLE_PRIVS
is 'Roles granted to users and roles'
/

