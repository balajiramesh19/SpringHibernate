create view CDB_ROLE_PRIVS as
  SELECT k."GRANTEE",k."GRANTED_ROLE",k."ADMIN_OPTION",k."DELEGATE_OPTION",k."DEFAULT_ROLE",k."COMMON",k."INHERITED",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_ROLE_PRIVS") k
/

comment on table CDB_ROLE_PRIVS
is 'Roles granted to users and roles in all containers'
/

