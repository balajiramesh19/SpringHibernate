create view ALL_IND_EXPRESSIONS as
  select io.name, idx.name, bo.name, base.name, c.default$, ic.pos#
from sys.col$ c, sys.obj$ idx, sys.obj$ base, sys.icol$ ic,
     sys.user$ io, sys.user$ bo, sys.ind$ i
where bitand(ic.spare1,1) = 1       /* an expression */
  and (bitand(i.property,1024) = 0) /* not bmji */
  and ic.bo# = c.obj#
  and ic.intcol# = c.intcol#
  and ic.bo# = base.obj#
  and io.user# = idx.owner#
  and bo.user# = base.owner#
  and ic.obj# = idx.obj#
  and idx.obj# = i.obj#
  and i.type# in (1, 2, 3, 4, 6, 7, 9)
  and (base.type# != 2 or 1 = (select 1 /* Exclude Binary XML Token set indexes */
           from sys.tab$ t
           where i.bo# = t.obj#
             and bitand(t.property, power(2,65)) = 0 or t.property is null))
  and (idx.owner# = userenv('SCHEMAID') or
       base.owner# = userenv('SCHEMAID')
       or
       base.obj# in ( select obj#
                     from sys.objauth$
                     where grantee# in ( select kzsrorol
                                         from x$kzsro
                                       )
                   )
        or
          /* user has system privileges */
        ora_check_sys_privilege ( base.owner#, base.type#) = 1
        or
        ora_check_sys_privilege ( idx.owner#, idx.type#) = 1
      )
/

comment on table ALL_IND_EXPRESSIONS
is 'FUNCTIONAL INDEX EXPRESSIONs on accessible TABLES'
/

