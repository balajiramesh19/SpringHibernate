create view V_$PATCHES as
  select "PATCH_ID","CON_ID" from v$patches
/

