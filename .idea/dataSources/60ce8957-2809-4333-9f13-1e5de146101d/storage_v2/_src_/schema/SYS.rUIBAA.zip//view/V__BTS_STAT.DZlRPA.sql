create view V_$BTS_STAT as
  select "TSN","TSV","MAXSIZE","CURSIZE","USED","UTIME","DALLOC","DFREE","NALLOC","NFREE","DTIME","TALLOC","TFREE","TTIME","FLAG","CON_ID" from v$bts_stat
/

