create view V_$STATS_ADVISOR_ACTIONS as
  select "RULE_ID","ACTION_FUNCTION","ACTION_TYPE","CON_ID" from v$stats_advisor_actions
/

