create view V_$STATS_ADVISOR_RATIONALES as
  select "RATIONALE_ID","RATIONALE_NAME","CON_ID" from v$stats_advisor_rationales
/

