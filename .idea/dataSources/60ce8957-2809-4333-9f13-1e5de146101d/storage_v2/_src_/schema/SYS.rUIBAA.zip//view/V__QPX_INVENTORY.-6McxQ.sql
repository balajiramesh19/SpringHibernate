create view V_$QPX_INVENTORY as
  select "NODE_NAME","PATCHES","CON_ID" from  v$qpx_inventory
/

