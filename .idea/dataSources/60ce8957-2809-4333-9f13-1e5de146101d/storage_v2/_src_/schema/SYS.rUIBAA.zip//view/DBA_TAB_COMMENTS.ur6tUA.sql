create view DBA_TAB_COMMENTS as
  select OWNER, TABLE_NAME,
       TABLE_TYPE,
       COMMENTS, ORIGIN_CON_ID
from INT$DBA_TAB_COMMENTS
/

comment on table DBA_TAB_COMMENTS
is 'Comments on all tables and views in the database'
/

