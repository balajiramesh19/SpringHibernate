create view USER_IND_COLUMNS as
  select
     INDEX_NAME, TABLE_NAME, COLUMN_NAME,
     COLUMN_POSITION, COLUMN_LENGTH,
     CHAR_LENGTH, DESCEND, COLLATED_COLUMN_ID
from user_ind_columns_v$
/

comment on table USER_IND_COLUMNS
is 'COLUMNs comprising user''s INDEXes and INDEXes on user''s TABLES'
/

