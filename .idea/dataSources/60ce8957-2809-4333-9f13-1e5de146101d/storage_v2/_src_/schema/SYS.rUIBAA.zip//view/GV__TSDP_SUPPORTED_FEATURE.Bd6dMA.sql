create view GV_$TSDP_SUPPORTED_FEATURE as
  select "INST_ID","FEATURE_NAME","FUNCTIONALITY","COMMENTS$","CON_ID" from gv$tsdp_supported_feature
/

