create view ALL_COL_COMMENTS as
  select OWNER, TABLE_NAME, COLUMN_NAME, COMMENTS, ORIGIN_CON_ID
from INT$DBA_COL_COMMENTS
where (OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OBJ_ID(OWNER, TABLE_NAME, OBJECT_TYPE#, OBJECT_ID) in
         (select obj#
          from sys.objauth$
          where grantee# in ( select kzsrorol
                              from x$kzsro
                            )
          )
       or
       /* 2 is the type# for Table. See kgl.h for more info */
       ora_check_sys_privilege ( ownerid, 2 ) = 1
      )
/

comment on table ALL_COL_COMMENTS
is 'Comments on columns of accessible tables and views'
/

