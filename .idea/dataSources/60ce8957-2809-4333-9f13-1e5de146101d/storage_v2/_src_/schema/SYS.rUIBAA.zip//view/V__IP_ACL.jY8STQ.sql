create view V_$IP_ACL as
  select "SERVICE_NAME","HOST","CON_ID" from v$ip_acl
/

