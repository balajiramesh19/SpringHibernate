create view GV_$GCR_STATUS as
  select "INST_ID","ITERATION","TIME","TYPE","DESCRIPTION","RESULT","CON_ID" from gv$gcr_status
/

