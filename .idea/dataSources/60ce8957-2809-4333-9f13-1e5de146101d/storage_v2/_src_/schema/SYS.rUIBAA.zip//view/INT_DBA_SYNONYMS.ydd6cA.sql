create view INT$DBA_SYNONYMS as
  select u.name, u.user#, o.name, o.type#, s.owner, s.name, s.node,
   case when bitand(o.flags, (65536+131072+4294967296))>0 then 1 else 0 end,
   to_number(sys_context('USERENV', 'CON_ID'))
from sys.user$ u, sys.syn$ s, sys."_CURRENT_EDITION_OBJ" o
where o.obj# = s.obj#
  and o.type# = 5
  and o.owner# = u.user#
/

