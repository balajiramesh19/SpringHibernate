create view V_$EXADIRECT_ACL as
  select "SERVICE_NAME","SGID","CON_ID" from v$exadirect_acl
/

