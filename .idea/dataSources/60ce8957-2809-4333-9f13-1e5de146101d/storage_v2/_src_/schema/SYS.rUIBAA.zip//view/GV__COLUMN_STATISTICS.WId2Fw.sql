create view GV_$COLUMN_STATISTICS as
  select "INST_ID","OBJ#","TS#","COLID","TRACK_TIME","STAT_TYPE","STAT_VAL_INT","STAT_VAL_STR","CON_ID" from gv$column_statistics
/

