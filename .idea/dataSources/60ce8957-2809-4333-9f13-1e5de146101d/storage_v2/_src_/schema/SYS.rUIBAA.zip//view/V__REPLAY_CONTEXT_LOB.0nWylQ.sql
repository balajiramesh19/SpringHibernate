create view V_$REPLAY_CONTEXT_LOB as
  select "CONTEXT_ID","LOB_ID","LOB_VERSION_BASE","LOB_VERSION_WRAP","MATCHED","CON_ID" from v$replay_context_lob
/

