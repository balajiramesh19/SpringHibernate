create view CDB_PROPERTIES as
  SELECT k."PROPERTY_NAME",k."PROPERTY_VALUE",k."DESCRIPTION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DATABASE_PROPERTIES") k
/

comment on table CDB_PROPERTIES
is 'Permanent database properties in all containers'
/

