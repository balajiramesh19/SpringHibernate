create view V_$RECOVERY_SLAVE as
  select "START_TIME","TYPE","ITEM","UNITS","SOFAR","TOTAL","COMMENTS","CON_ID" from v$recovery_slave
/

