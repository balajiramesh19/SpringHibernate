create view GV_$SQL_REOPTIMIZATION_HINTS as
  select "INST_ID","ADDRESS","HASH_VALUE","SQL_ID","CHILD_NUMBER","HINT_ID","HINT_TEXT","CLIENT_ID","REPARSE","CON_ID" from gv$sql_reoptimization_hints
/

