create view DBA_EDITIONED_TYPES as
  select u.name,
       decode(ue.type#, 4, 'VIEW', 5, 'SYNONYM',
                     7, 'PROCEDURE', 8, 'FUNCTION', 9, 'PACKAGE',
                     11, 'PACKAGE BODY', 12, 'TRIGGER',
                     13, 'TYPE', 14, 'TYPE BODY',
                     22, 'LIBRARY', 87, 'ASSEMBLY',
                     114, 'SQL TRANSLATION PROFILE',
                     'UNDEFINED')
from sys.user_editioning$ ue, sys.user$ u
where ue.user# = u.user# and ue.type# != 10
/

