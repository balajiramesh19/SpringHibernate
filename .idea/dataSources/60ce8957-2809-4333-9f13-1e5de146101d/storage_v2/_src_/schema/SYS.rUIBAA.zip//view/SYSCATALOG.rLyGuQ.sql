create view SYSCATALOG as
  select tname, creator, tabletype, remarks
  from syscatalog_
/

