create view GV_$HANG_STATISTICS as
  select "INST_ID","STATISTIC#","NAME","VALUE","CON_ID" from gv$hang_statistics
/

