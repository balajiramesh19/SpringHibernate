create view "_INT$_ALL_SYNONYMS_FOR_SYN" as
  select s.obj#, u.name, o.name, s.owner, s.name,
       s.node, bo.obj#,
       case when bitand(o.flags, (65536+131072+4294967296))>0 then 1 else 0 end,
       to_number(sys_context('USERENV', 'CON_ID'))
from sys.syn$ s, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u,
     sys."_CURRENT_EDITION_OBJ" bo, sys.user$ bu
where s.owner = bu.name         /* get the owner id for the base object */
  and bu.user# = bo.owner#      /* get the obj$ entry for the base object */
  and s.name = bo.name          /* get the obj$ entry for the base object */
  and bo.type# = 5              /* restrict to synonyms for synonyms */
  and o.obj# = s.obj#
  and o.type# = 5
  and o.owner# = u.user#
/

