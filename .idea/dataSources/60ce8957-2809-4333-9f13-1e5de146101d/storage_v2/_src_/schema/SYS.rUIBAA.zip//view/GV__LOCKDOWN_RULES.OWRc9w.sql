create view GV_$LOCKDOWN_RULES as
  select "INST_ID","RULE_TYPE","RULE","CLAUSE","CLAUSE_OPTION","STATUS","USERS","CON_ID" from gv$lockdown_rules
/

