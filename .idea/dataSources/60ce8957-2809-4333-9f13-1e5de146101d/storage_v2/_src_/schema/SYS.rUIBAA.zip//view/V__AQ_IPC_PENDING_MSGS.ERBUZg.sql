create view V_$AQ_IPC_PENDING_MSGS as
  select "SEQUENCE_NUMBER","MSG_CLASS_NAME","MSG_FLAGS","MSG_SUBMT_TIME","CON_ID" from v$aq_ipc_pending_msgs
/

