create view CDB_LOG_GROUPS as
  SELECT k."OWNER",k."LOG_GROUP_NAME",k."TABLE_NAME",k."LOG_GROUP_TYPE",k."ALWAYS",k."GENERATED",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_LOG_GROUPS") k
/

comment on table CDB_LOG_GROUPS
is 'Log group definitions on all tables in all containers'
/

