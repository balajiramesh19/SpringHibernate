create view "_BASE_USER" as
  select USER#,TYPE#,DATATS#,TEMPTS#,CTIME,PTIME,EXPTIME,LTIME,
       RESOURCE$,AUDIT$,DEFROLE,DEFGRP#,DEFGRP_SEQ#,ASTATUS,
       LCOUNT,DEFSCHCLASS,EXT_USERNAME,SPARE1,SPARE2,SPARE6,
       decode(u.type#, 2, substr(u.ext_username, 0, 30), u.name)
from sys.user$ u
/

