create view V_$STATS_ADVISOR_RULES as
  select "RULE_ID","NAME","RULE_TYPE","DESCRIPTION","CON_ID" from v$stats_advisor_rules
/

