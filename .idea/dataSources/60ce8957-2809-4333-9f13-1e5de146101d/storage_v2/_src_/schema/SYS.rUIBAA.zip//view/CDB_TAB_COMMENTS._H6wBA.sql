create view CDB_TAB_COMMENTS as
  SELECT k."OWNER",k."TABLE_NAME",k."TABLE_TYPE",k."COMMENTS",k."ORIGIN_CON_ID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_TAB_COMMENTS") k
/

comment on table CDB_TAB_COMMENTS
is 'Comments on all tables and views in the database in all containers'
/

