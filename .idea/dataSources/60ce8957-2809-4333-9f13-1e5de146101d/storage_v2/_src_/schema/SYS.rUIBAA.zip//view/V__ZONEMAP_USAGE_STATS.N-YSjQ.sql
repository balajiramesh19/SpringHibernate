create view V_$ZONEMAP_USAGE_STATS as
  select "ZONEMAP","PRUNING_TYPE","EXECUTIONS","BASE_COUNT","PRUNED_COUNT","CON_ID" from v$zonemap_usage_stats
/

