create view GV_$PROCESS_POOL as
  select "INST_ID","POOL_NAME","ENABLED","MIN_COUNT","BATCH_COUNT","INIT_COUNT","CUR_COUNT","MAX_COUNT","CON_ID" from gv$process_pool
/

