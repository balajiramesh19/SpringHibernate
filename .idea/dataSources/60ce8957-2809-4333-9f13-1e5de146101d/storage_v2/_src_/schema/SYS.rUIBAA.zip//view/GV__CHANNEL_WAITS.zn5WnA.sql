create view GV_$CHANNEL_WAITS as
  select "INST_ID","CHANNEL","MESSAGES_PUBLISHED","WAIT_COUNT","WAIT_TIME_USEC","CON_ID" from gv$channel_waits
/

