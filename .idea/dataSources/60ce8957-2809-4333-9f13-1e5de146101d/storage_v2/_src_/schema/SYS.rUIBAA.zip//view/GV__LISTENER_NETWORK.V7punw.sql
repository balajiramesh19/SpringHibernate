create view GV_$LISTENER_NETWORK as
  select "INST_ID","NETWORK","TYPE","VALUE","CON_ID" from gv$listener_network
/

