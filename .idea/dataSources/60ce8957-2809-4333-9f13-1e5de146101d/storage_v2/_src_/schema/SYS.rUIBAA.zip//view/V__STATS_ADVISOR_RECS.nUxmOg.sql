create view V_$STATS_ADVISOR_RECS as
  select "REC_ID","RATIONALE_ID","REC_NAME","CON_ID" from v$stats_advisor_recs
/

