create view GV_$JAVA_PATCHING_STATUS as
  select "INST_ID","OPERATION","STATUS","CON_ID" from gv$java_patching_status
/

