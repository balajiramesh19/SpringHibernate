create view GV_$DML_STATS as
  select "INST_ID","OBJN","INS","UPD","DEL","DROPSEG","CURROWS","PAROBJN","LASTUSED","FLAGS","CON_ID" from gv$dml_stats
/

