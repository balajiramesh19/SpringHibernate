create view INDEX_STATS as
  select kdxstrot+1      height,
        kdxstsbk        blocks,
        o.name,
        o.subname       partition_name,
        kdxstlrw        lf_rows,
        kdxstlbk        lf_blks,
        kdxstlln        lf_rows_len,
        kdxstlub        lf_blk_len,
        kdxstbrw        br_rows,
        kdxstbbk        br_blks,
        kdxstbln        br_rows_len,
        kdxstbub        br_blk_len,
        kdxstdrw        del_lf_rows,
        kdxstdln        del_lf_rows_len,
        kdxstdis        distinct_keys,
        kdxstmrl        most_repeated_key,
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,
        kdxstlln+kdxstbln+kdxstlvl              used_space,
        ceil(((kdxstlln+kdxstbln)*100)/
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))
                                                pct_used,
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)
                                                blks_gets_per_access,
        kdxstnpr        pre_rows,
        kdxstpln        pre_rows_len,
        kdxstokc        opt_cmpr_count,
        kdxstpsk        opt_cmpr_pctsave,
        kdxstncd        del_lf_cmp_rows,
        kdxstncp        prg_lf_cmp_rows,
        kdxstncr        lf_cmp_rows,
        kdxstlcr        lf_cmp_rows_len,
        kdxstnur        lf_uncmp_rows,
        kdxstlur        lf_uncmp_rows_len,
        kdxstlsr        lf_suf_rows_len,
        kdxstlcu        lf_cmp_rows_uncmp_len,
        kdxstrcc        lf_cmp_recmp_count,
        kdxstlvl        lf_cmp_lock_vec_len,
        kdxstncb        lf_cmp_blks,
        kdxstnub        lf_uncmp_blks
  from obj$ o, ind$ i, seg$ s, x$kdxst
 where kdxstobj = o.obj# and kdxstfil = s.file#
  and  kdxstblk = s.block#
  and  kdxsttsn = s.ts#
  and  s.file#  = i.file#
  and  s.block# = i.block#
  and  s.ts# = i.ts#
  and  i.obj#   = o.obj#
union all
 select kdxstrot+1      height,
        kdxstsbk        blocks,
        o.name,
        o.subname       partition_name,
        kdxstlrw        lf_rows,
        kdxstlbk        lf_blks,
        kdxstlln        lf_rows_len,
        kdxstlub        lf_blk_len,
        kdxstbrw        br_rows,
        kdxstbbk        br_blks,
        kdxstbln        br_rows_len,
        kdxstbub        br_blk_len,
        kdxstdrw        del_lf_rows,
        kdxstdln        del_lf_rows_len,
        kdxstdis        distinct_keys,
        kdxstmrl        most_repeated_key,
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,
        kdxstlln+kdxstbln+kdxstlvl              used_space,
        ceil(((kdxstlln+kdxstbln)*100)/
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))
                                                pct_used,
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)
                                                blks_gets_per_access,
        kdxstnpr        pre_rows,
        kdxstpln        pre_rows_len,
        kdxstokc        opt_cmpr_count,
        kdxstpsk        opt_cmpr_pctsave,
        kdxstncd        del_lf_cmp_rows,
        kdxstncp        prg_lf_cmp_rows,
        kdxstncr        lf_cmp_rows,
        kdxstlcr        lf_cmp_rows_len,
        kdxstnur        lf_uncmp_rows,
        kdxstlur        lf_uncmp_rows_len,
        kdxstlsr        lf_suf_rows_len,
        kdxstlcu        lf_cmp_rows_uncmp_len,
        kdxstrcc        lf_cmp_recmp_count,
        kdxstlvl        lf_cmp_lock_vec_len,
        kdxstncb        lf_cmp_blks,
        kdxstnub        lf_uncmp_blks
  from obj$ o, seg$ s, indpart$ ip, x$kdxst
 where kdxstobj = o.obj# and kdxstfil = s.file#
  and  kdxstblk = s.block#
  and  kdxsttsn = s.ts#
  and  s.file#  = ip.file#
  and  s.block# = ip.block#
  and  s.ts#    = ip.ts#
  and  ip.obj#  = o.obj#
union all
 select kdxstrot+1      height,
        kdxstsbk        blocks,
        o.name,
        o.subname       partition_name,
        kdxstlrw        lf_rows,
        kdxstlbk        lf_blks,
        kdxstlln        lf_rows_len,
        kdxstlub        lf_blk_len,
        kdxstbrw        br_rows,
        kdxstbbk        br_blks,
        kdxstbln        br_rows_len,
        kdxstbub        br_blk_len,
        kdxstdrw        del_lf_rows,
        kdxstdln        del_lf_rows_len,
        kdxstdis        distinct_keys,
        kdxstmrl        most_repeated_key,
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,
        kdxstlln+kdxstbln+kdxstlvl              used_space,
        ceil(((kdxstlln+kdxstbln)*100)/
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))
                                                pct_used,
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)
                                                blks_gets_per_access,
        kdxstnpr        pre_rows,
        kdxstpln        pre_rows_len,
        kdxstokc        opt_cmpr_count,
        kdxstpsk        opt_cmpr_pctsave,
        kdxstncd        del_lf_cmp_rows,
        kdxstncp        prg_lf_cmp_rows,
        kdxstncr        lf_cmp_rows,
        kdxstlcr        lf_cmp_rows_len,
        kdxstnur        lf_uncmp_rows,
        kdxstlur        lf_uncmp_rows_len,
        kdxstlsr        lf_suf_rows_len,
        kdxstlcu        lf_cmp_rows_uncmp_len,
        kdxstrcc        lf_cmp_recmp_count,
        kdxstlvl        lf_cmp_lock_vec_len,
        kdxstncb        lf_cmp_blks,
        kdxstnub        lf_uncmp_blks
  from obj$ o, seg$ s, indsubpart$ isp, x$kdxst
 where kdxstobj = o.obj# and kdxstfil = s.file#
  and  kdxstblk = s.block#
  and  kdxsttsn = s.ts#
  and  s.file#  = isp.file#
  and  s.block# = isp.block#
  and  s.ts#    = isp.ts#
  and  isp.obj#  = o.obj#
/

comment on table INDEX_STATS
is 'statistics on the b-tree'
/

