create view CDB_PARTIAL_DROP_TABS as
  SELECT k."OWNER",k."TABLE_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_PARTIAL_DROP_TABS") k
/

comment on table CDB_PARTIAL_DROP_TABS
is 'All tables with partially dropped columns in the database in all containers'
/

