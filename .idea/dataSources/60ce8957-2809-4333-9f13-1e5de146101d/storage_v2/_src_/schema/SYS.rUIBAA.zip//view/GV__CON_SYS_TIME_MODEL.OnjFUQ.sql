create view GV_$CON_SYS_TIME_MODEL as
  select "INST_ID","STAT_ID","STAT_NAME","VALUE","CON_ID" from gv$con_sys_time_model
/

