create view V_$SESSIONS_COUNT as
  select "CON_ID","USER_SESSION_COUNT","RECURSIVE_SESSION_COUNT" from v$sessions_count
/

