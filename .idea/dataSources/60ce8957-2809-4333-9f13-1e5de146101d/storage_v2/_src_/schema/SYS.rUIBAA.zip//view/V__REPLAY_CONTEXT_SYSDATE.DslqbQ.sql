create view V_$REPLAY_CONTEXT_SYSDATE as
  select "CONTEXT_ID","SYSDATE_VALUE","REPLAYED","CON_ID" from v$replay_context_sysdate
/

