create view CDB_UPDATABLE_COLUMNS as
  SELECT k."OWNER",k."TABLE_NAME",k."COLUMN_NAME",k."UPDATABLE",k."INSERTABLE",k."DELETABLE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_UPDATABLE_COLUMNS") k
/

comment on table CDB_UPDATABLE_COLUMNS
is 'Description of dba updatable columns in all containers'
/

