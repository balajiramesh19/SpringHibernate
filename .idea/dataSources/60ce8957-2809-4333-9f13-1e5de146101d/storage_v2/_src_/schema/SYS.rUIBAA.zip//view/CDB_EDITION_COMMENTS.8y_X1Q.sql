create view CDB_EDITION_COMMENTS as
  SELECT k."EDITION_NAME",k."COMMENTS",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_EDITION_COMMENTS") k
/

comment on table CDB_EDITION_COMMENTS
is 'Describes comments on all editions in the database in all containers'
/

