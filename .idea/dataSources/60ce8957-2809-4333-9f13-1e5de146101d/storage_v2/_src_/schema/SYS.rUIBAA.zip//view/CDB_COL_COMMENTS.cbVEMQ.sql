create view CDB_COL_COMMENTS as
  SELECT k."OWNER",k."TABLE_NAME",k."COLUMN_NAME",k."COMMENTS",k."ORIGIN_CON_ID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_COL_COMMENTS") k
/

comment on table CDB_COL_COMMENTS
is 'Comments on columns of all tables and views in all containers'
/

