create view CDB_ENCRYPTED_COLUMNS as
  SELECT k."OWNER",k."TABLE_NAME",k."COLUMN_NAME",k."ENCRYPTION_ALG",k."SALT",k."INTEGRITY_ALG",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_ENCRYPTED_COLUMNS") k
/

comment on table CDB_ENCRYPTED_COLUMNS
is 'Encryption information on columns in the database in all containers'
/

