create view GV_$JAVA_SERVICES as
  select "INST_ID","NAME","CON_ID" from gv$java_services
/

