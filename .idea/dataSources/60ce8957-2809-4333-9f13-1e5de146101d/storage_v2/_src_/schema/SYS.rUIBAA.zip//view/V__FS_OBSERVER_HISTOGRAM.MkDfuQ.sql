create view V_$FS_OBSERVER_HISTOGRAM as
  select "OBSERVER_NAME","OBSERVER_HOST","WAIT_TIME","WAIT_COUNT","LAST_UPDATE_TIME","CON_ID" from v$fs_observer_histogram
/

