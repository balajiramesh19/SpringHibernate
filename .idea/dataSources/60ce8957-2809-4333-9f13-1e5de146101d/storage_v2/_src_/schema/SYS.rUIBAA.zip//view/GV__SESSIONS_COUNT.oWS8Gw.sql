create view GV_$SESSIONS_COUNT as
  select "INST_ID","CON_ID","USER_SESSION_COUNT","RECURSIVE_SESSION_COUNT" from gv$sessions_count
/

