create view GV_$XS_SESSIONS as
  select "INST_ID","SID","DB_SID","SERIAL#","CON_ID" from gv$xs_sessions
/

