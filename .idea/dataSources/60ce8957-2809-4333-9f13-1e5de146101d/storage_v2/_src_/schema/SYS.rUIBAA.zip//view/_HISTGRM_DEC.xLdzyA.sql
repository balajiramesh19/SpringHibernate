create view "_HISTGRM_DEC" as
  select
  obj#,
  col#,
  row#,
  bucket,
  case when endpoint_enc is not null
    then dbms_crypto_internal.statsDecryptNum ( obj#, intcol#, endpoint_enc )
    else endpoint
  end endpoint,
  intcol#,
  epvalue,
  ep_repeat_count,
  case when endpoint_enc is not null
    then dbms_crypto_internal.statsDecryptRaw ( obj#, intcol#, epvalue_raw )
    else epvalue_raw
  end epvalue_raw,
  spare1,
  spare2
from histgrm$ hg
/

