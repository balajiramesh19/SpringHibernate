create view GV_$OPTIMIZER_PROCESSING_RATE as
  select "INST_ID","ADDR","OPERATION_NAME","MANUAL_VALUE","CALIBRATION_VALUE","DEFAULT_VALUE","CON_ID" from gv$optimizer_processing_rate
/

