create view V_$XS_SESSIONS as
  select "SID","DB_SID","SERIAL#","CON_ID" from v$xs_sessions
/

