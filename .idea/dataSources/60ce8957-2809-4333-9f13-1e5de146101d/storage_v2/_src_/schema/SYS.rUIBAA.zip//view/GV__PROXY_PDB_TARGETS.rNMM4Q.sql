create view GV_$PROXY_PDB_TARGETS as
  select "INST_ID","CON_ID","TARGET_PORT","TARGET_HOST","TARGET_SERVICE","TARGET_USER" from gv$proxy_pdb_targets
/

