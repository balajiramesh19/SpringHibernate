create view GV_$IM_ADOTASKS as
  select "INST_ID","TASK_ID","CREATION_TIME","STATUS","IM_SIZE","CON_ID" from gv$im_adotasks
/

