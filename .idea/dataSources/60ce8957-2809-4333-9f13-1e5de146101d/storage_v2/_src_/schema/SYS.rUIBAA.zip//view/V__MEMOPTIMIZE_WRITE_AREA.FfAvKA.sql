create view V_$MEMOPTIMIZE_WRITE_AREA as
  select "TOTAL_SIZE","USED_SPACE","FREE_SPACE","NUM_WRITES","NUM_WRITERS","CON_ID" from v$memoptimize_write_area
/

