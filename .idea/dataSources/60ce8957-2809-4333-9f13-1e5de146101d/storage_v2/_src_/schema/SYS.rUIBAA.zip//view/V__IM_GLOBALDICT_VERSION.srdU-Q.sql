create view V_$IM_GLOBALDICT_VERSION as
  select "CON_ID","HEAD_ADDRESS","PMAP_HEAD_ADDRESS","VERSION_ID","REFCOUNT","FLAGS","SPARE" from v$im_globaldict_version
/

