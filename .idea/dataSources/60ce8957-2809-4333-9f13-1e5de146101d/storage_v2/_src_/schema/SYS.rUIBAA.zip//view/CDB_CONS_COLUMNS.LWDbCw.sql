create view CDB_CONS_COLUMNS as
  SELECT k."OWNER",k."CONSTRAINT_NAME",k."TABLE_NAME",k."COLUMN_NAME",k."POSITION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_CONS_COLUMNS") k
/

comment on table CDB_CONS_COLUMNS
is 'Information about accessible columns in constraint definitions in all containers'
/

