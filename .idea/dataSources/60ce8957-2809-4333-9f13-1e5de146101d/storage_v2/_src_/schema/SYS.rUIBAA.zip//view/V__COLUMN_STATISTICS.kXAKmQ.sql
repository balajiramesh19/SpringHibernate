create view V_$COLUMN_STATISTICS as
  select "OBJ#","TS#","COLID","TRACK_TIME","STAT_TYPE","STAT_VAL_INT","STAT_VAL_STR","CON_ID" from v$column_statistics
/

