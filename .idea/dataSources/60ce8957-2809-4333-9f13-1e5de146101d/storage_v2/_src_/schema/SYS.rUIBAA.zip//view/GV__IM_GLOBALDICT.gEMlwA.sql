create view GV_$IM_GLOBALDICT as
  select "INST_ID","CON_ID","DOMAIN#","HEAD_ADDRESS","LASTFREE","FLAGS","SPARE","REFCOUNT" from gv$im_globaldict
/

