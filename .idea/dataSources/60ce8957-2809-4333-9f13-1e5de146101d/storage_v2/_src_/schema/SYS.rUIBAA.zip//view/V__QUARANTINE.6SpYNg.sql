create view V_$QUARANTINE as
  select "OBJECT","ADDRESS","BYTES","ERROR","TIMESTAMP","CON_ID" from v$quarantine
/

