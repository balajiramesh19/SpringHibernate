create view DBA_SYNONYMS as
  select OWNER, SYNONYM_NAME, TABLE_OWNER, TABLE_NAME, DB_LINK,
       ORIGIN_CON_ID
from   INT$DBA_SYNONYMS
/

comment on table DBA_SYNONYMS
is 'All synonyms in the database'
/

