create view ALL_CLUSTER_HASH_EXPRESSIONS as
  select us.name, o.name, c.condition
from sys.cdef$ c, sys.user$ us, sys.obj$ o
where c.type#   = 8
and   c.obj#   = o.obj#
and   us.user# = o.owner#
and   ( us.user# = userenv('SCHEMAID')
        or  /* user has system privileges */
        ora_check_sys_privilege ( o.owner#, o.type# ) = 1
      )
/

comment on table ALL_CLUSTER_HASH_EXPRESSIONS
is 'Hash functions for all accessible clusters'
/

