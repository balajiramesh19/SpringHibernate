create view INDEX_HISTOGRAM as
  select hist.indx * power(2, stats.kdxstscl-4)  repeat_count,
        hist.kdxhsval                           keys_with_repeat_count
        from  x$kdxst stats, x$kdxhs hist
/

comment on table INDEX_HISTOGRAM
is 'statistics on keys with repeat count'
/

