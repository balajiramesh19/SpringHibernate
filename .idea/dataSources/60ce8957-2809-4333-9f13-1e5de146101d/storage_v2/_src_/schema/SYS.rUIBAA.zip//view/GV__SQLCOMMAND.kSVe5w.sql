create view GV_$SQLCOMMAND as
  select "INST_ID","COMMAND_TYPE","COMMAND_NAME","CON_ID" from gv$sqlcommand
/

