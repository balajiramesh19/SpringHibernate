create view V_$EXP_STATS as
  select "EXPID","OBJNUM","DYNCOST","EVALCNT","CON_ID" from v$exp_stats
/

