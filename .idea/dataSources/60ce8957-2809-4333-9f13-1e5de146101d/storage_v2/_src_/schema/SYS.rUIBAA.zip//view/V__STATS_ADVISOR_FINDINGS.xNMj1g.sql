create view V_$STATS_ADVISOR_FINDINGS as
  select "FINDING_ID","RULE_ID","REC_ID","FINDING_NAME","CON_ID" from v$stats_advisor_findings
/

