create view V_$CODE_CLAUSE as
  select "CODE_ID#","CLAUSE_ID#","CLAUSE_NAME","PARAMETER_NAME","CON_ID" from v$code_clause
/

