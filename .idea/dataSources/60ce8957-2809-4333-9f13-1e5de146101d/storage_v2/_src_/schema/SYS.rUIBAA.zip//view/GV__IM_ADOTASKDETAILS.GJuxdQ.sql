create view GV_$IM_ADOTASKDETAILS as
  select "INST_ID","TASK_ID","OBJ#","ACTION","STATUS","CON_ID" from gv$im_adotaskdetails
/

