create view V_$IM_SMU_CHUNK as
  select "TSN","OBJD","OBJN","STARTDBA","VERSION","CHUNK_ID","CHUNK_ADDRESS","ULE_COUNT","CON_ID" from v$IM_smu_chunk
/

