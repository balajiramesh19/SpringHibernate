create view DBA_EDITIONS as
  select o.name, po.name, decode(bitand(e.flags,1),1,'NO','YES')
from sys.obj$ o, sys.edition$ e, sys.obj$ po
where o.obj# = e.obj#
  and po.obj# (+)= e.p_obj#
/

comment on table DBA_EDITIONS
is 'Describes all editions in the database'
/

