create view GV_$DIAG_TRACE_FILE as
  select "INST_ID","ADR_HOME","TRACE_FILENAME","CHANGE_TIME","MODIFY_TIME","CON_ID" from gv$diag_trace_file
/

