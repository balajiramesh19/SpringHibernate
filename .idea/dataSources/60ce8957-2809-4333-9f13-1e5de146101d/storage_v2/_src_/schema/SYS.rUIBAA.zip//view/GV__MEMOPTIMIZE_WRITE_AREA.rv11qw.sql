create view GV_$MEMOPTIMIZE_WRITE_AREA as
  select "INST_ID","TOTAL_SIZE","USED_SPACE","FREE_SPACE","NUM_WRITES","NUM_WRITERS","CON_ID" from gv$memoptimize_write_area
/

