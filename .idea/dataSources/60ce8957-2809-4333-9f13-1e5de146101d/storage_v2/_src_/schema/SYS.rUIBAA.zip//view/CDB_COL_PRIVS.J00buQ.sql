create view CDB_COL_PRIVS as
  SELECT k."GRANTEE",k."OWNER",k."TABLE_NAME",k."COLUMN_NAME",k."GRANTOR",k."PRIVILEGE",k."GRANTABLE",k."COMMON",k."INHERITED",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_COL_PRIVS") k
/

comment on table CDB_COL_PRIVS
is 'All grants on columns in the database in all containers'
/

