create view GV_$GCR_LOG as
  select "INST_ID","ITERATION","TIME","TYPE","DESCRIPTION","RESULT","CON_ID" from gv$gcr_log
/

