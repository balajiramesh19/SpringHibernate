create view USER_TAB_COMMENTS as
  select TABLE_NAME, TABLE_TYPE, COMMENTS, ORIGIN_CON_ID
from NO_ROOT_SW_FOR_LOCAL(INT$DBA_TAB_COMMENTS)
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
/

comment on table USER_TAB_COMMENTS
is 'Comments on the tables and views owned by the user'
/

