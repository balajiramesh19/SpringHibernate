create view V_$EDITIONABLE_TYPES as
  select "EDITIONABLE_TYPE","TYPE#","CON_ID" from v$editionable_types
/

