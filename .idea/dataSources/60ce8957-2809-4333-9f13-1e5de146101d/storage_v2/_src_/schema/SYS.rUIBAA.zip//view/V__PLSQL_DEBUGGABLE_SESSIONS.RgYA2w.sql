create view V_$PLSQL_DEBUGGABLE_SESSIONS as
  select sid, serial#, logon_time, user#, username,
         osuser, process, machine, port, terminal, program, type, service_name,
         plsql_debugger_connected, con_id
    from v_$session s
   where type in ('USER') and
         ((sid = sys_context('USERENV', 'SID') and
           user# = sys_context('USERENV', 'CURRENT_USERID') and
           exists (select null from v$enabledprivs
                    where priv_number in (-238 /* DEBUG CONNECT SESSION */)))
          or
          (exists (select null from sys.userauth$ ua
                    where ua.user# = s.user# and
                          ua.grantee# in (select kzsrorol from x$kzsro) and
                          ua.privilege# in (3 /* DEBUG CONNECT ON USER */)))
          or
          (username not in ('SYS', 'XDB') and
           exists (select null from v$enabledprivs
                    where priv_number in (-240 /* DEBUG CONNECT ANY */)))
          or
          sys_context('USERENV', 'CURRENT_USERID') = 0)
/

