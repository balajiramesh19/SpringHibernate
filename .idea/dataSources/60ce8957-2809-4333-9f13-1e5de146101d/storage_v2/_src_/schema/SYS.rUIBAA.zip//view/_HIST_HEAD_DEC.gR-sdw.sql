create view "_HIST_HEAD_DEC" as
  select
  obj#,
  col#,
  bucket_cnt,
  row_cnt,
  cache_cnt,
  null_cnt,
  timestamp#,
  sample_size,
  case when bitand(spare2,1024) = 1024
    then dbms_crypto_internal.statsDecryptNum( obj#, intcol#, minimum_enc )
    else minimum
  end minimum,
  case when bitand(spare2,1024) = 1024
    then dbms_crypto_internal.statsDecryptNum( obj#, intcol#, maximum_enc )
     else maximum
  end maximum,
  distcnt,
  case when bitand(spare2,1024) = 1024
    then dbms_crypto_internal.statsDecryptRaw( obj#, intcol#, lowval )
    else lowval
  end lowval,
  case when bitand(spare2,1024) = 1024
    then dbms_crypto_internal.statsDecryptRaw( obj#, intcol#, hival )
    else hival
  end hival,
  density,
  intcol#,
  spare1,
  spare2,
  avgcln,
  spare3,
  spare4
from hist_head$ h
/

