create view USER_ENCRYPTED_COLUMNS as
  select TABLE_NAME, COLUMN_NAME, ENCRYPTION_ALG,SALT, INTEGRITY_ALG from DBA_ENCRYPTED_COLUMNS
  where OWNER = SYS_CONTEXT('USERENV','CURRENT_USER')
/

comment on table USER_ENCRYPTED_COLUMNS
is 'Encryption information on columns of tables owned by the user'
/

