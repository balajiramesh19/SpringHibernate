create view GV_$IM_GLOBALDICT_SORTORDER as
  select "INST_ID","CON_ID","HEAD_ADDRESS","VERSION_ID","START_CODE","NUM_SYMBOLS","TOTAL_LENGTH","FLAGS","SPARE" from gv$im_globaldict_sortorder
/

