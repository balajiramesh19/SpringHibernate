create view CDB_TAB_PRIVS as
  SELECT k."GRANTEE",k."OWNER",k."TABLE_NAME",k."GRANTOR",k."PRIVILEGE",k."GRANTABLE",k."HIERARCHY",k."COMMON",k."TYPE",k."INHERITED",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_TAB_PRIVS") k
/

comment on table CDB_TAB_PRIVS
is 'All grants on objects in the database in all containers'
/

