create view GV_$AQ_IPC_PENDING_MSGS as
  select "INST_ID","SEQUENCE_NUMBER","MSG_CLASS_NAME","MSG_FLAGS","MSG_SUBMIT_TIME","CON_ID" from gv$aq_ipc_pending_msgs
/

