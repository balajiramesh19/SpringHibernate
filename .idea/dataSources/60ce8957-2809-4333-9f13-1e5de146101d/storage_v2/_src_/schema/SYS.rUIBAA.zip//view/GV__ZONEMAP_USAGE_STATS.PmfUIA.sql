create view GV_$ZONEMAP_USAGE_STATS as
  select "INST_ID","ZONEMAP","PRUNING_TYPE","EXECUTIONS","BASE_COUNT","PRUNED_COUNT","CON_ID" from gv$zonemap_usage_stats
/

