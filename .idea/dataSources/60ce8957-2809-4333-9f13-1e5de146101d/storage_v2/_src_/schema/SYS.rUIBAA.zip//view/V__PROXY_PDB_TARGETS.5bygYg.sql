create view V_$PROXY_PDB_TARGETS as
  select "CON_ID","TARGET_PORT","TARGET_HOST","TARGET_SERVICE","TARGET_USER" from v$proxy_pdb_targets
/

