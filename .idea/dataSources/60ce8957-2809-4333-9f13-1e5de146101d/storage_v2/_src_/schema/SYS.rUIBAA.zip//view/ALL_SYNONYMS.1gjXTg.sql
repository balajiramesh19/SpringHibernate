create view ALL_SYNONYMS as
  select OWNER, SYNONYM_NAME, TABLE_OWNER, TABLE_NAME, DB_LINK,
       ORIGIN_CON_ID
from INT$DBA_SYNONYMS
where (
       OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER = 'PUBLIC'
       or /* local object, and user has system privileges */
         (DB_LINK is null
          and
          ora_check_sys_privilege ( ownerid, object_type#) = 1
         )
       or /* user has any privs on base object in local database */
        exists
        (select null
         from sys.objauth$ ba, sys."_CURRENT_EDITION_OBJ" bo, sys.user$ bu
         where DB_LINK is null
           and bu.name = TABLE_OWNER
           and bo.name = TABLE_NAME
           and bu.user# = bo.owner#
           and ba.obj# = bo.obj#
           and (   ba.grantee# in (select kzsrorol from x$kzsro)
                or ba.grantor# = USERENV('SCHEMAID')
               )
        )
      )
union
select st.SYN_OWNER, st.SYN_SYNONYM_NAME, st.SYN_TABLE_OWNER,
       st.SYN_TABLE_NAME, st.SYN_DB_LINK, st.ORIGIN_CON_ID
from sys."_ALL_SYNONYMS_TREE" st
/

comment on table ALL_SYNONYMS
is 'All synonyms for base objects accessible to the user and session'
/

