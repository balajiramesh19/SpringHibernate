create view CDB_CLUSTER_HASH_EXPRESSIONS as
  SELECT k."OWNER",k."CLUSTER_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_CLUSTER_HASH_EXPRESSIONS") k
/

comment on table CDB_CLUSTER_HASH_EXPRESSIONS
is 'Hash functions for all clusters in all containers'
/

