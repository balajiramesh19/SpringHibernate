create view FLASHBACK_TRANSACTION_QUERY as
  select xid, start_scn, start_timestamp,
          decode(commit_scn, 0, commit_scn, 281474976710655, NULL, commit_scn)
          commit_scn, commit_timestamp,
          logon_user, undo_change#, operation, table_name, table_owner,
          row_id, undo_sql
from sys.x$ktuqqry
/

comment on table FLASHBACK_TRANSACTION_QUERY
is 'Description of the flashback transaction query view'
/

