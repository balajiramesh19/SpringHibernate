create view V_$TOPLEVELCALL as
  select "TOP_LEVEL_CALL#","TOP_LEVEL_CALL_NAME","CON_ID" from v$toplevelcall
/

