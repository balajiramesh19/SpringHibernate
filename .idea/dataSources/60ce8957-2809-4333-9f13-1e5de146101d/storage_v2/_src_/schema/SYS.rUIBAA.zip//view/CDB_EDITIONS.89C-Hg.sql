create view CDB_EDITIONS as
  SELECT k."EDITION_NAME",k."PARENT_EDITION_NAME",k."USABLE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_EDITIONS") k
/

comment on table CDB_EDITIONS
is 'Describes all editions in the database in all containers'
/

