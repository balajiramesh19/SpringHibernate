create view GV_$IM_TBS_EXT_MAP as
  select "INST_ID","START_DBA","END_DBA","DATAOBJ","IMCU_ADDR","LEN","SMU_ADDR","CON_ID" from gv$im_tbs_ext_map
/

