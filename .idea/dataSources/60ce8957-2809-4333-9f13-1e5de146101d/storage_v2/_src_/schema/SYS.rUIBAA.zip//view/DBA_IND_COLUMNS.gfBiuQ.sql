create view DBA_IND_COLUMNS as
  select
     INDEX_OWNER, INDEX_NAME,
     TABLE_OWNER, TABLE_NAME,
     COLUMN_NAME, COLUMN_POSITION, COLUMN_LENGTH,
     CHAR_LENGTH, DESCEND, COLLATED_COLUMN_ID
from dba_ind_columns_v$
/

comment on table DBA_IND_COLUMNS
is 'COLUMNs comprising INDEXes on all TABLEs and CLUSTERs'
/

