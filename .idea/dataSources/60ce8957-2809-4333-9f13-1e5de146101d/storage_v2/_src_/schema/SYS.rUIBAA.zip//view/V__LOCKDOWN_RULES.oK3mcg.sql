create view V_$LOCKDOWN_RULES as
  select "RULE_TYPE","RULE","CLAUSE","CLAUSE_OPTION","STATUS","USERS","CON_ID" from v$lockdown_rules
/

