create view V_$DIAG_TRACE_FILE as
  select "ADR_HOME","TRACE_FILENAME","CHANGE_TIME","MODIFY_TIME","CON_ID" from v$diag_trace_file
/

