create view V_$OPTIMIZER_PROCESSING_RATE as
  select "ADDR","OPERATION_NAME","MANUAL_VALUE","CALIBRATION_VALUE","DEFAULT_VALUE","CON_ID" from v$optimizer_processing_rate
/

