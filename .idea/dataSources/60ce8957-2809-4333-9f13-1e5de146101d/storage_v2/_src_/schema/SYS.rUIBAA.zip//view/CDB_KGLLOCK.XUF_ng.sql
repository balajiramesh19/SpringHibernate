create view CDB_KGLLOCK as
  SELECT k."KGLLKUSE",k."KGLLKHDL",k."KGLLKMOD",k."KGLLKREQ",k."KGLLKTYPE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_KGLLOCK") k
/

comment on table CDB_KGLLOCK
is ' in all containers'
/

