create view GV_$PATCHES as
  select "INST_ID","PATCH_ID","CON_ID" from gv$patches
/

